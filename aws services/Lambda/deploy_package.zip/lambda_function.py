import boto3
import botocore
import json
import mysql.connector
import os
import pandas

from datetime import datetime
from io import StringIO
from mysql.connector import errorcode


aws_access_key = os.environ['aws_access_key']
aws_secret_access_key = os.environ['aws_secret_access_key']
    

tables_metadata = [
    {
        'NAME': 'jobs',
        'FIELDS': [
            'id',
            'job'
        ]
    },
    {
        'NAME': 'departments',
        'FIELDS': [
            'id',
            'department'
        ]
    },
    {
        'NAME': 'hired_employees',
        'FIELDS': [
            'id',
            'name',
            'datetime',
            'department_id',
            'job_id'
        ]
    }
]


def aws_client(service, region):
    print('Making client for aws service, ', service)
    
    try:
        client = boto3.client(service, 
            aws_access_key_id = aws_access_key,
            aws_secret_access_key = aws_secret_access_key,
            region_name = region)
    
        return client
    
    except botocore.exceptions.ClientError as error:
        print('error, conecction to aws service: ', error)
        raise error


def read_csv(region, bucket, object):
    s3_client = aws_client('s3', region)
    
    print('Loading csv file: ', object)
    
    csv_obj = s3_client.get_object(Bucket = bucket, Key = object)
    body = csv_obj['Body']
    csv_string = body.read().decode('utf-8')
    
    return csv_string


def get_parameter_store(region):
    print('Get parameters for aws parameter store')
    
    ssm_client = aws_client('ssm', region)
    
    user = ssm_client.get_parameter(Name = '/RDS/MySQL/globant-db/User', WithDecryption = True)['Parameter']['Value']
    passwd = ssm_client.get_parameter(Name = '/RDS/MySQL/globant-db/Password', WithDecryption = True)['Parameter']['Value']
    host = ssm_client.get_parameter(Name = '/RDS/MySQL/globant-db/Host')['Parameter']['Value']
    db_name = ssm_client.get_parameter(Name = '/RDS/MySQL/globant-db/Database')['Parameter']['Value']
    
    db_access = {
        'user': user,
        'password': passwd,
        'host': host,
        'database': db_name
    }
    
    return db_access


def db_conn(data_access):
    print('Connecting to database')
    
    try:
        conn = mysql.connector.connect(**data_access)
        return conn

    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            print("Something is wrong with your user name or password")
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            print("Database does not exist")
        else:
            print(err)
        raise err


def build_insert_query(table_data):
    QUERY_TEMPLATE = "INSERT INTO {} ({}) VALUES({})"

    table_name = table_data['NAME']
    table_fields = ','.join(table_data['FIELDS'])

    string_parameters_list = []

    for _ in range(0, len(table_data['FIELDS'])):
        string_parameters_list.append('%s')

    string_parameters = ','.join(string_parameters_list)

    query = QUERY_TEMPLATE.format(table_name, table_fields, string_parameters)
    print('Query to execute: ', query)
    
    return query


def write_csv(df, file_name, region):
    csv_buffer = StringIO()
    df.to_csv(csv_buffer, header = False, index = False)
    s3_client = aws_client('s3', region)
    date = datetime.now().strftime("%Y%m%d_%H%M%S")
    s3_client.put_object(Bucket = 'globant-invalid-data', Body = csv_buffer.getvalue(), Key = file_name + '_' + date + '.csv')


def exec_query(db, data, table, region):
    
    query = build_insert_query(table)

    try:
        with db as db_conn, db_conn.cursor() as db_cursor:
            
            df = pandas.read_csv(StringIO(data), header = None)
            df.columns = table['FIELDS']
            df_ok = df.dropna()
            print('df_ok: ', df_ok)
            
            df_ok = list(df_ok.itertuples(index = False, name = None))
            
            db_cursor.executemany(query, df_ok)
            db_conn.commit()
            
            print('Query executed')

            df_wrong = df[df.isna().any(axis=1)]
            print('df_wrong: ', df_wrong)

            write_csv(df_wrong, table['NAME'], region)

    except Exception as e:
        raise e

    finally:
        db.close()
        

def lambda_handler(event, context):
    
    event_js = json.loads(str(event).replace("'", '"'))
    print('event: ', event_js)
    
    region = event_js['Records'][0]['awsRegion']
    landing_bucket = event_js['Records'][0]['s3']['bucket']['name']
    object_key = event_js['Records'][0]['s3']['object']['key']

    csv_data = read_csv(region, landing_bucket, object_key)
    
    db_access = get_parameter_store(region)
    
    my_db_conn = db_conn(db_access)
    
    for t in tables_metadata:
        if t['NAME'] == object_key.replace('.csv', ''):
            table = t
    
    exec_query(my_db_conn, csv_data, table, region)
    
    print('Execution finished.')
    